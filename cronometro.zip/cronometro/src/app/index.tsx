import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
} from 'react-native';

function pad(n: number): string {
  return n.toString().padStart(2, '0');
}

export default function CronometroApp() {
  const [tempo, setTempo] = useState(0);
  const [rodando, setRodando] = useState(false);
  const [voltas, setVoltas] = useState<number[]>([]);
  const intervaloRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const minutos = Math.floor(tempo / 6000);
  const segundos = Math.floor((tempo % 6000) / 100);
  const centesimos = tempo % 100;

  const handleIniciarPausar = () => {
    if (rodando) {
      if (intervaloRef.current) {
        clearInterval(intervaloRef.current);
        intervaloRef.current = null;
      }
      setRodando(false);
    } else {
      intervaloRef.current = setInterval(() => {
        setTempo((t) => t + 1);
      }, 10);
      setRodando(true);
    }
  };

  const handleVolta = () => {
    if (rodando || tempo > 0) {
      setVoltas((v) => [tempo, ...v]);
    }
  };

  const handleReset = () => {
    if (intervaloRef.current) {
      clearInterval(intervaloRef.current);
      intervaloRef.current = null;
    }
    setRodando(false);
    setTempo(0);
    setVoltas([]);
  };

  return (
    <SafeAreaView style={styles.outerContainer}>
      <View style={styles.phoneFrame}>
        <View style={styles.phoneScreen}>

          <Text style={styles.title}>Cronômetro</Text>

          <View style={styles.displayContainer}>
            <Text style={styles.displayTempo}>
              {pad(minutos)}:{pad(segundos)}
            </Text>
            <Text style={styles.displayCentesimos}>.{pad(centesimos)}</Text>
          </View>

          <View style={styles.botoesContainer}>
            <TouchableOpacity
              style={[styles.botao, styles.botaoSecundario]}
              onPress={handleVolta}
              activeOpacity={0.75}
            >
              <Text style={styles.botaoTextoSecundario}>Volta</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.botao,
                styles.botaoPrincipal,
                rodando && styles.botaoPausar,
              ]}
              onPress={handleIniciarPausar}
              activeOpacity={0.75}
            >
              <Text style={styles.botaoTextoPrincipal}>
                {rodando ? 'Pausar' : tempo === 0 ? 'Iniciar' : 'Continuar'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.botao, styles.botaoSecundario]}
              onPress={handleReset}
              activeOpacity={0.75}
            >
              <Text style={styles.botaoTextoSecundario}>Reset</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.voltasContainer}>
            {voltas.length === 0 ? (
              <Text style={styles.voltasVazioTexto}>Nenhuma volta registrada</Text>
            ) : (
              <ScrollView showsVerticalScrollIndicator={false}>
                {voltas.map((v, i) => {
                  const vm = Math.floor(v / 6000);
                  const vs = Math.floor((v % 6000) / 100);
                  const vc = v % 100;
                  return (
                    <View key={i} style={styles.voltaItem}>
                      <Text style={styles.voltaNumero}>
                        Volta {voltas.length - i}
                      </Text>
                      <Text style={styles.voltaTempo}>
                        {pad(vm)}:{pad(vs)}.{pad(vc)}
                      </Text>
                    </View>
                  );
                })}
              </ScrollView>
            )}
          </View>

        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  outerContainer: {
    flex: 1,
    backgroundColor: '#e8e8e8',
    alignItems: 'center',
    justifyContent: 'center',
  },
  phoneFrame: {
    borderWidth: 12,
    borderColor: '#111111',
    borderRadius: 36,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 16,
    elevation: 12,
  },
  phoneScreen: {
    width: 300,
    height: 520,
    backgroundColor: '#f1f2f6',
    alignItems: 'center',
    paddingVertical: 30,
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#2f3542',
    letterSpacing: 0.5,
    marginBottom: 16,
  },
  displayContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginBottom: 24,
  },
  displayTempo: {
    fontSize: 56,
    fontWeight: '200',
    color: '#2f3542',
    letterSpacing: 2,
    fontVariant: ['tabular-nums'],
  },
  displayCentesimos: {
    fontSize: 28,
    fontWeight: '200',
    color: '#747d8c',
    marginBottom: 8,
    letterSpacing: 1,
    fontVariant: ['tabular-nums'],
  },
  botoesContainer: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 20,
  },
  botao: {
    width: 78,
    height: 42,
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
  },
  botaoPrincipal: {
    backgroundColor: '#2ed573',
  },
  botaoPausar: {
    backgroundColor: '#ff6b81',
  },
  botaoSecundario: {
    backgroundColor: '#dfe4ea',
  },
  botaoTextoPrincipal: {
    color: '#2f3542',
    fontWeight: '700',
    fontSize: 13,
  },
  botaoTextoSecundario: {
    color: '#57606f',
    fontWeight: '600',
    fontSize: 13,
  },
  voltasContainer: {
    flex: 1,
    width: '100%',
    borderTopWidth: 1,
    borderTopColor: '#dfe4ea',
    paddingTop: 10,
  },
  voltasVazioTexto: {
    textAlign: 'center',
    color: '#a4b0be',
    fontSize: 13,
    marginTop: 10,
  },
  voltaItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 0.5,
    borderBottomColor: '#dfe4ea',
  },
  voltaNumero: {
    fontSize: 14,
    color: '#747d8c',
  },
  voltaTempo: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2f3542',
    fontVariant: ['tabular-nums'],
  },
});
